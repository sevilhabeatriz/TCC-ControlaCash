function navegarParaPagina(pagina) {
  window.location.href = pagina;
}

function mostrarSaldo() {
  const saldo = document.getElementById("saldo");
  const showBalanceButton = document.getElementById("show-balance-button");

  if (saldo.style.display === "none") {
      saldo.style.display = "block";
  } else {
      saldo.style.display = "none";
  }
}

const yellowSubmenu = document.querySelector(".yellow-submenu");
const submenu = document.querySelector(".submenu");

yellowSubmenu.addEventListener("click", function () {
  if (submenu.style.display === "block") {
      submenu.style.display = "none";
  } else {
      submenu.style.display = "block";
  }
})

function toggleSubmenu() {
  const yellowSubmenu = document.querySelector(".yellow-submenu");
  yellowSubmenu.classList.toggle("open");
}

function mostrarOpcao(imagem, conteudo) {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");
  modal.style.display = "block";
  modalContent.innerHTML = `
      <span class="close" onclick="fecharModal()">&times;</span>
      <h2>${imagem}</h2>
      <p>${conteudo}</p>`;
}

function fecharModal() {
  const modal = document.getElementById("modal");
  modal.style.display = "none";
};