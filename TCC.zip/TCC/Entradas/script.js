function retornarParaTelaAnterior() {
    window.history.back();
  }