function retornarParaTelaAnterior() {
    window.history.back();
  }

// Supondo que você tenha dados de entradas e saídas
const entradasESaidas = [
  { tipo: 'Entrada', data: '2023-11-24', valor: 500, tipoRenda: 'Estorno', tipoPagamento: 'Débito' },
  { tipo: 'Saída', data: '2023-11-24', valor: 500, tipoGasto: 'Investimento', tipoPagamento: 'Crédito' },
  // ... outros registros de entradas e saídas
];
console.log("verificado")

// Função para gerar os dias do mês no formato 'YYYY-MM-DD'
function diasDoMes(ano, mes) {
  const dias = new Date(ano, mes, 0).getDate();
  return Array.from({ length: dias }, (_, i) => `${ano}-${mes.toString().padStart(2, '0')}-${(i + 1).toString().padStart(2, '0')}`);
}

// Organize os dados pela data
entradasESaidas.sort((a, b) => new Date(a.data) - new Date(b.data));

const agruparPorTipoEDia = () => {
  const agrupados = {};
  entradasESaidas.forEach(item => {
    const chave = `${item.data}_${item.tipo}`;
    if (!agrupados[chave]) {
      agrupados[chave] = { data: item.data, tipo: item.tipo, valor: item.valor };
    } else {
      agrupados[chave].valor += item.valor;
    }
  });
  return Object.values(agrupados);
};

// Obtenha os valores agrupados
const dadosAgrupados = agruparPorTipoEDia();

// Prepare os datasets para o gráfico
const labels = diasDoMes(new Date().getFullYear(), new Date().getMonth() + 1); // Dias do mês atual

// Separe os dados por tipo (Entrada ou Saída)
const dadosEntrada = entradasESaidas.filter(item => item.tipo === 'Entrada');
const dadosSaida = entradasESaidas.filter(item => item.tipo === 'Saída');

// Calcular espaçamento entre os dias e largura das barras
const totalDias = labels.length;
const totalBarrasPorDia = Math.max(dadosEntrada.length, dadosSaida.length);
const larguraDaBarra = totalBarrasPorDia > 1 ? 0.8 : 0.5; // Ajuste a largura conforme o número de barras

// Crie os datasets para Entrada e Saída
const datasetEntrada = {
  label: 'Entrada',
  data: labels.map((dia, index) => {
    const entradasDoDia = dadosEntrada.filter(item => item.data === dia);
    const valor = entradasDoDia.reduce((acc, curr) => acc + curr.valor, 0);
    const detalhes = entradasDoDia.map(entrada => `Tipo de Renda: ${entrada.tipoRenda || 'Não especificado'}, Tipo de Pagamento: ${entrada.tipoPagamento || 'Não especificado'}`);
    return { valor, detalhes };
  }),
  backgroundColor: '#688154', // Cor verde para entradas
  borderWidth: 1,
  barPercentage: 1, // Definir uma porcentagem de barra igual a 1
};

const datasetSaida = {
  label: 'Saída',
  data: labels.map((dia, index) => {
    const saidasDoDia = dadosSaida.filter(item => item.data === dia);
    const valor = saidasDoDia.reduce((acc, curr) => acc + curr.valor, 0);
    const detalhes = saidasDoDia.map(saida => `Tipo de Gasto: ${saida.tipoGasto || 'Não especificado'}, Tipo de Pagamento: ${saida.tipoPagamento || 'Não especificado'}`);
    return { valor, detalhes };
  }),
  backgroundColor: '#F4BC33', // Cor amarela para saídas
  borderWidth: 1,
  barPercentage: 1, // Definir uma porcentagem de barra igual a 1
};

datasetEntrada.data = datasetEntrada.data.map(item => item.valor);
datasetSaida.data = datasetSaida.data.map(item => item.valor);


// Crie o gráfico de barras
const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: labels,
    datasets: [datasetEntrada, datasetSaida]
  },
  options: {
    indexAxis: 'x',
    plugins: {
      legend: {
        display: true,
        position: 'top'
      }
    },
    layout: {
      padding: {
        top: 20,
        right: 20,
        bottom: 20,
        left: 20
      },
      tooltips: {
        callbacks: {
          title:function (tooltipItem) {
            const dataIndex = tooltipItem[0].dataIndex;
            return labels[dataIndex];
          },
          label: function (tooltipItem, data) {
            const datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
            const value = tooltipItem.formattedValue || tooltipItem.value;
  
            // Encontrar o item específico associado ao dia e ao tipo (Entrada ou Saída)
            const targetItem = entradasESaidas.find(item =>
              item.data === labels[tooltipItem.dataIndex] &&
              item.tipo === datasetLabel
            );
  
            if (!targetItem) return '';
  
            // Montar o texto a ser exibido no tooltip
            let tooltipText = '';
            if (targetItem.tipo === 'Entrada') {
              tooltipText = `Tipo de Renda: ${targetItem.tipoRenda || 'Não especificada'}, Pagamento: ${targetItem.tipoPagamento || 'Não especificado'}`;
            } else {
              tooltipText = `Tipo de Gasto: ${targetItem.tipoGasto || 'Não especificado'}, Pagamento: ${targetItem.tipoPagamento || 'Não especificado'}`;
            }
  
            return `${tooltipText}, Valor: ${value}`;
          }
        },
        bodyFont: {
          size: 14 // Ajuste o tamanho da fonte do tooltip
        },
        padding: 30, // Ajuste o preenchimento interno do tooltip
        displayColors: false, // Remova a exibição das cores no tooltip, se necessário
        backgroundColor: 'rgba(0, 0, 0, 0.7)', // Cor de fundo do tooltip
        bodySpacing: 8 // Espaçamento entre linhas no corpo do tooltip
      }
    },
    maintainAspectRatio: false, // Desativar o ajuste automático do tamanho
    responsive: false, // Desativar a responsividade
    scales: {
      x: {
        stacked: false,
        grid: {
          display: false
        },
        ticks: {
          autoSkip: false // Desativar o pulo automático entre rótulos
        }
      },
      y: {
        stacked: false, // Altere para false para mostrar as barras lado a lado
        beginAtZero: true
      }
    },
    barGroup: {
      groupWidth: '70%' // Espaçamento entre grupos de barras
    }
  },
  // Defina a largura e altura do canvas do gráfico
  // ...
});