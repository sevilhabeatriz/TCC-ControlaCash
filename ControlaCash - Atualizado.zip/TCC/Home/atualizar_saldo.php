<?php
include 'C:/xampp/htdocs/conexão.php';

$stmt = $pdo->prepare("SELECT * FROM saldo WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

function obterSaldo($conn) {
    $sql = "SELECT saldo FROM saldo WHERE id = 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['saldo'];
    } else {
        return 0.00;
    }
}

function atualizarSaldo($conn, $novoSaldo) {
    $sql = "UPDATE saldo SET saldo = $novoSaldo WHERE id = 1";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false
    }
}

$conn->close();
?>