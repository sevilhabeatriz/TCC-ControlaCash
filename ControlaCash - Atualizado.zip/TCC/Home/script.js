function navegarParaPagina(pagina) {
  window.location.href = pagina;
}

let saldo = 0;

function exibirSaldoNaTelaHome() {
  const saldoElement = document.getElementById('saldo');

  saldoElement.textContent = `Saldo: R$${saldo.toFixed(2)}`;
}

function adicionarValorAoSaldo() {
  const valorDaEntrada = parseFloat(localStorage.getItem('valorDaEntrada'));

  if (!isNaN(valorDaEntrada)) {
    saldo += valorDaEntrada;
    exibirSaldoNaTelaHome();
  }
}

adicionarValorAoSaldo();

function mostrarSaldo() {
  const saldo = document.getElementById("saldo");
  const showBalanceButton = document.getElementById("show-balance-button");

  if (saldo.style.display === "none") {
      saldo.style.display = "block";
  } else {
      saldo.style.display = "none";
  }
}

const yellowSubmenu = document.querySelector(".yellow-submenu");
const submenu = document.querySelector(".submenu");

yellowSubmenu.addEventListener("click", function () {
  if (submenu.style.display === "block") {
      submenu.style.display = "none";
  } else {
      submenu.style.display = "block";
  }
})

function toggleSubmenu() {
  const yellowSubmenu = document.querySelector(".yellow-submenu");
  yellowSubmenu.classList.toggle("open");
}

function mostrarOpcao(imagem, conteudo) {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");
  modal.style.display = "block";
  modalContent.innerHTML = `
      <span class="close" onclick="fecharModal()">&times;</span>
      <h2>${imagem}</h2>
      <p>${conteudo}</p>`;
}

function sair() {
  window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Login/login.html";
}

function fecharModal() {
  const modal = document.getElementById("modal");
  modal.style.display = "none";
};