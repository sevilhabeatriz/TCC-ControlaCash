function login() {
  const emailInput = document.getElementById("emailInput").value;
  const passwordInput = document.getElementById("passwordInput").value;
  const errorMessage = document.getElementById("errorMessage");

  // Verificar se o e-mail é válido
  if (!isValidEmail(emailInput)) {
      errorMessage.innerText = "E-mail inválido ou incorreto!";
  } else {
      // Obter dados salvos no armazenamento local
      const savedEmail = localStorage.getItem("userEmail");
      const savedPassword = localStorage.getItem("userPassword");

      // Verificar se os dados de login coincidem com os dados salvos
      if (emailInput === savedEmail && passwordInput === savedPassword) {
          // Se o login for bem-sucedido, redirecione para a tela principal
          window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Home/home.html";
      } else {
          if (!savedEmail) {
              errorMessage.innerText = "Faça o seu cadastro para continuar!";
          } else if (emailInput.trim() === "" || passwordInput.trim() === "") {
              errorMessage.innerText = "Preencha os campos!";
          } else {
              errorMessage.innerText = "E-mail ou senha incorretos!";
          }
      }
  }
}

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

  function cadastrar() {
    window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Cadastro/cadastro.html";
  }