<?php
include 'conexão.php';

$stmt = $pdo->prepare("SELECT * FROM saidas WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

$saidaId = $data['saidaId'];
$tipoGasto = $data['tipoGasto'];
$valor = $data['valor'];
$tipoPagamentoS = $data['tipoPagamentoS'];

$sql = "UPDATE saidas SET tipo_gasto=?, valor=?, tipo_pagamentos=? WHERE id_unico=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $tipoGasto, $valor, $tipoPagamentoS, $saidaId);

if ($stmt->execute()) {
    echo "Saida atualizada com sucesso!";
} else {
    echo "Erro ao atualizar saida: " . $conn->error;
}

$stmt->close();
$conn->close();
?>