function retornarParaTelaAnterior() {
  window.history.back();
}

function validarValorNegativo(input) {
  if (input.value < 0) {
      input.value = 0;
  }
}

document.getElementById('valorInputS').addEventListener('input', function() {
  let inputValue = this.value;

  let formattedValue = parseFloat(inputValue).toFixed(2);

  this.value = formattedValue;
});

function mostrarMenuSaida() {
  const exitMenu = document.getElementById('exitMenu');
  exitMenu.classList.toggle('hidden');
}

function alternarVisibilidadeElemento(valor, elemento) {
  if (valor === 'OutroS') {
    elemento.classList.remove('hidden');
  } else {
    elemento.classList.add('hidden');
  }
}

function mostrarOutroGasto() {
  const tipoGasto = document.getElementById('tipoGasto');
  const outroGasto = document.getElementById('outroGasto');
  alternarVisibilidadeElemento(tipoGasto.value, outroGasto);
}

function mostrarOutroPagamentoS() {
  const tipoPagamentoS = document.getElementById('tipoPagamentoS');
  const outroPagamentoS = document.getElementById('outroPagamentoS');
  alternarVisibilidadeElemento(tipoPagamentoS.value, outroPagamentoS);
}

function criarIDUnico() {
  return 'saida_' + Date.now(); // Exemplo: saida_1637375104447
}

function atualizarSaldo(valor) {
  saldo += parseFloat(valor);
  mostrarSaldo();
}

function salvarSaida() {
  const dataAtualS = new Date();
  const dataFormatadaS = `${dataAtualS.toLocaleDateString()} ${dataAtualS.toLocaleTimeString()}`;

  const tipoGasto = document.getElementById('tipoGasto').value;
  const valorS = document.getElementById('valorInputS').value;
  const tipoPagamentoS = document.getElementById('tipoPagamentoS').value;

  const saidasSalvas = document.getElementById('saidasSalvas');

  const novaSaida = document.createElement('div');
  const saidaId = criarIDUnico();
  novaSaida.id = saidaId;

  novaSaida.classList.add('saved-exit');
  novaSaida.innerHTML = `
  <div class="data-criacao">${dataFormatadaS}</div>
      <p>Tipo de Gasto: ${tipoGasto}</p>
      <p>Valor: R$${valorS}</p>
      <p>Tipo de Pagamento: ${tipoPagamentoS}</p>
  `;

  saidasSalvas.appendChild(novaSaida);

  novaSaida.classList.add('saida');

  const btnEditar = document.createElement('button');
  btnEditar.textContent = 'Editar';
  btnEditar.classList.add('editar');
  btnEditar.onclick = function() {
      editarSaida(saidaId);
  };

  const btnExcluir = document.createElement('button');
  btnExcluir.textContent = 'Excluir';
  btnExcluir.classList.add('excluir');
  btnExcluir.onclick = function() {
      excluirSaida(saidaId);
  };

  novaSaida.appendChild(btnEditar);
  novaSaida.appendChild(btnExcluir);

  const valorNumericoS = parseFloat(valorS);

  saldo -= valorNumericoS;

  atualizarSaldo(valorS);
  enviarValorParaHome(valorNumericoS);

  const formData = new FormData();
  formData.append('tipoGasto', tipoGasto);
  formData.append('valor', valorS);
  formData.append('tipoPagamentoS', tipoPagamentoS);

  fetch('salvar_saida.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    carregarSaidas();
  })
  .catch(error => console.error('Erro:', error));
  
  fetch('salvar_saida.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      saidaId: saidaId,
      tipoGasto: tipoGasto,
      valor: valorS,
      tipoPagamentoS: tipoPagamentoS
  })
})
.then(response => response.text())
.then(data => {
    console.log(data);
    carregarSaidas();
})
.catch(error => console.error('Erro:', error));
}

function enviarValorParaHome(valor) {
  localStorage.setItem('valorDaSaida', valor);
}

function cancelarSaida() {
  document.getElementById('valorInputS').value = '';
  exitMenu.classList.toggle('hidden');
}

function atualizarSaidaNoServidor(saidaId, novotipoGasto, novoValorS, novotipoPagamentoS) {
  fetch('atualizar_saida.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({
          saidaId: saidaId,
          tipoGasto: novotipoGasto,
          valor: novoValorS,
          tipoPagamentoS: novotipoPagamentoS
      })
  })
  .then(response => response.text())
  .then(data => {
      console.log(data);
      carregarSaidas();
  })
  .catch(error => console.error('Erro:', error));
}

function carregarSaidas() {
  fetch('buscar_saidas.php', {
      method: 'GET',
      headers: {
      'Content type': 'application/json'
      }
  })
  .then(response => response.text())
  .then(data => {
      const saidasSalvas = document.getElementById('saidasSalvas');

      saidasSalvas.innerHTML = '';

      data.forEach(saida => {
          const novaSaida = document.createElement('div');
          novaSaida.classList.add('saved-exit');
          novaSaida.innerHTML = `
              <p>Data de Criação: ${dataFormatadaS}</p>
              <p>Tipo de Gasto: ${tipoGasto}</p>
              <p>Valor: R$${valorInputS}</p>
              <p>Tipo de Pagamento: ${tipoPagamentoS}</p>
          `;
          saidasSalvas.appendChild(novaSaida);
      });
  })
  .catch(error => console.error('Erro ao buscar saidas:', error));
}

function editarSaida(saidaId) {

  const tipoGastoEdit = document.getElementById(`tipoGasto_${saidaId}`).textContent;
  const valorEditS = document.getElementById(`valorInputS_${saidaId}`).textContent;
  const tipoPagamentoSEdit = document.getElementById(`tipoPagamentoS_${saidaId}`).textContent;

  const novaSaida = document.getElementById(saidaId);
  const dataCriacao = novaSaida.querySelector('.data-criacao').textContent;

  const formEdicao = document.querySelector('.form-edicaoS');
  formEdicao.querySelector('.saida-id').value = saidaId;
  formEdicao.querySelector('.tipo-gasto-edit').value = tipoGastoEdit;
  formEdicao.querySelector('.valor-s-edit').value = valorEditS;
  formEdicao.querySelector('.tipo-pagamento-s-edit').value = tipoPagamentoSEdit;
  formEdicao.querySelector('.data-criacao-edit').textContent = dataCriacao;

  novaSaida.style.display = 'none';
  formEdicao.style.display = 'block';

  fetch('atualizar_saida.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    saidaId: saidaId,
    tipoGasto: tipoGastoEdit,
    valorInputS: valorEditS,
    tipoPagamentoS: tipoPagamentoSEdit
    })
  })
  .then(response => response.text())
  .then(data => {
    console.log(data); 
    carregarSaidas();
  })
  .catch(error => console.error('Erro:', error));
}

function confirmarEdicao() {
  const saidaId = document.querySelector('.saida-id').value;
  const novotipoGasto = document.querySelector('.tipo-gasto-edit').value;
  const novoValorS = document.querySelector('.valor-s-edit').value;
  const novotipoPagamentoS = document.querySelector('.tipo-pagamento-s-edit').value;

  atualizarSaidaNoServidor(saidaId, novotipoGasto, novoValorS, novotipoPagamentoS);

  const saidaEditada = document.getElementById(saidaId);
  if (saidaEditada) {
      saidaEditada.querySelector('.tipo-gasto-edit').textContent = `Tipo de Gasto: ${novotipoGasto}`;
      saidaEditada.querySelector('.valor-s-edit').textContent = `Valor: ${novoValorS}`;
      saidaEditada.querySelector('.tipo-pagamento-s-edit').textContent = `Tipo de Pagamento: ${novotipoPagamentoS}`;
  }

  const formEdicao = document.querySelector('.form-edicaoS');
  formEdicao.style.display = 'none';
}

function salvarEdicao(saidaId) {
  const saidaEditada = document.getElementById(saidaId);
  if (saidaEditada) {
      const novotipoGasto = saidaEditada.querySelector('.tipo-gasto-edit').value;
      const novoValorS = saidaEditada.querySelector('.valor-s-edit').value;
      const novotipoPagamentoS = saidaEditada.querySelector('.tipo-pagamento-s-edit').value;


      enviarDadosAtualizadosAoServidor(saidaId, novotipoGasto, novoValorS, novotipoPagamentoS);
  }
}

function enviarDadosAtualizadosAoServidor(saidaId, novotipoGasto, novoValorS, novotipoPagamentoS) {
  // Aqui você deve enviar uma requisição AJAX para o servidor para atualizar os dados no banco de dados
  fetch('atualizar_saida.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          saidaId: saidaId,
          tipoGasto: novotipoGasto,
          valor: novoValorS,
          tipoPagamentoS: novotipoPagamentoS
      })
  })
  .then(response => response.text())
  .then(data => {
      console.log(data);
      carregarSaidas();
      // Por exemplo, esconder a interface de edição e atualizar os dados na saida exibida
  })
  .catch(error => console.error('Erro:', error));
}

function excluirSaida(saidaId) {
  fetch('excluir_saida.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      saidaId: saidaId
    })
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    carregarSaidas();
  })
  .catch(error => console.error('Erro:', error));
}

function preencherFormularioEdicao(saida) {
  const saidaId = saida.querySelector('.saida-id').value;
  const tipoGasto = saida.querySelector('.tipoGasto').textContent;
  const valor = saida.querySelector('.valorInputS').numberContent;
  const tipoPagamentoS = saida.querySelector('.tipoPagamentoS').textContent;

  const formEdicao = document.querySelector('.form-edicaoS');
  formEdicao.querySelector('.saida-id').value = saidaId;
  formEdicao.querySelector('.tipo-gasto-edit').value = tipoGasto;
  formEdicao.querySelector('.valor-s-edit').value = valor;
  formEdicao.querySelector('.tipo-pagamento-s-edit').value = tipoPagamentoS;

  saida.style.display = 'none';
  formEdicao.style.display = 'block';
}

function cancelarEdicaoS() {
  const formEdicao = document.querySelector('.form-edicaoS');
  formEdicao.style.display = 'none';

  const saidaId = document.querySelector('.saida-id').value;
  const saidaOriginal = document.getElementById(saidaId);
  if (saidaOriginal) {
    saidaOriginal.style.display = 'block';
  }
}