<?php
include 'conexão.php';

$stmt = $pdo->prepare("SELECT * FROM saidas WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

$saidaId = $data['saidaId'];

$sql = "DELETE FROM saidas WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $saidaId);

if ($stmt->execute()) {
    echo "Saida excluída com sucesso!";
} else {
    echo "Erro ao excluir saida: " . $conn->error;
}

$stmt->close();
$conn->close();
?>