<?php
include 'conexão.php';

$stmt = $pdo->prepare("SELECT * FROM saidas WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

$saidaId = $_POST['saidaId'];
$dataFormatadaS = date("Y-m-d H:i:s");
$tipoGasto = $_POST['tipoGasto'];
$valor = $_POST['valor'];
$tipoPagamentoS = $_POST['tipoPagamentoS'];

$sql = "INSERT INTO saidas (id_unico, data_criacaos, tipo_gasto, valor, tipo_pagamentos) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $saidaId, $dataFormatadaS, $tipoGasto, $valor, $tipoPagamentoS);

if ($stmt->execute()) {
    echo "Saida salva com sucesso!";
} else {
    echo "Erro ao salvar saida: " . $conn->error;
}

$stmt->close();
$conn->close();
?>