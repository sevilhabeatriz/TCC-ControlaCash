<?php
include 'conexão.php';

$stmt = $pdo->prepare("SELECT * FROM saidas WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

$sql = "SELECT * FROM saidas";
$result = $conn->query($sql);

$saidas = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $saidas[] = $row;
    }
}

$conn->close();

echo json_encode($saidas);
?>