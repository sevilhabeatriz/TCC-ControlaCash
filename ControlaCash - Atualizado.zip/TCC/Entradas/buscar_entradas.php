<?php
include 'C:/xampp/htdocs/conexão.php';

$stmt = $pdo->prepare("SELECT * FROM entradas WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

$entradas = array();

$sql = "SELECT * FROM entradas ORDER BY data_criacao DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $entradas[] = $row;
    }
}

echo json_encode($entradas); // Retorna os dados em formato JSON para o JavaScript

$conn->close();
?>