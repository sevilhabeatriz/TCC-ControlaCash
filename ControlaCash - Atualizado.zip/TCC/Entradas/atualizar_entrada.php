<?php
include 'C:/xampp/htdocs/conexão.php';

$stmt = $pdo->prepare("SELECT * FROM entradas WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

$entradaId = $_POST['entradaId'];
$tipoRenda = $_POST['tipoRenda'];
$valor = $_POST['valor'];
$tipoPagamento = $_POST['tipoPagamento'];

$sql = "UPDATE entradas SET tipo_renda=?, valor=?, tipo_pagamento=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssi", $tipoRenda, $valor, $tipoPagamento, $entradaId);

if ($stmt->execute()) {
    echo "Entrada atualizada com sucesso!";
} else {
    echo "Erro ao atualizar entrada: " . $conn->error;
}

$stmt->close();
$conn->close();
?>