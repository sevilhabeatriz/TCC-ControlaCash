<?php
include 'C:/xampp/htdocs/conexão.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $entradaId = $_POST["entradaId"];

  $stmt = $conn->prepare("DELETE FROM entradas WHERE entradaId = ?");
  $stmt->bind_param("i", $entradaId);

  if ($stmt->execute()) {
    echo "Entrada excluída com sucesso!";
  } else {
    echo "Erro ao excluir entrada: " . $conn->error;
  }

  $stmt->close();
  $conn->close();
}
?>