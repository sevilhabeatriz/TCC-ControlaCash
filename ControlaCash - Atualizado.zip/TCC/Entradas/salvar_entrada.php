<?php
include 'C:/xampp/htdocs/conexão.php';

$stmt = $pdo->prepare("SELECT * FROM entradas WHERE id = :id");
$stmt->execute(['id' => $id]);
$result = $stmt->fetch();

$dataFormatada = date("Y-m-d H:i:s");
$tipoRenda = $_POST['tipoRenda'];
$valor = $_POST['valor'];
$tipoPagamento = $_POST['tipoPagamento'];

// Prepara e executa a inserção no banco de dados
$stmt = $conn->prepare("INSERT INTO entradas (tipo_renda, valor, tipo_pagamento, data_criacao) VALUES (?, ?, ?, ?)");
$stmt->bind_param("sds", $tipoRenda, $valor, $tipoPagamento, $dataFormatada);

if ($stmt->execute()) {
    echo "Entrada salva com sucesso!";
} else {
    echo "Erro ao salvar entrada: " . $conn->error;
}

$stmt->close();
$conn->close();
?>