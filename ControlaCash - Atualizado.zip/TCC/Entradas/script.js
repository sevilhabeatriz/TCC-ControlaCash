function retornarParaTelaAnterior() {
  window.history.back();
}

document.addEventListener('DOMContentLoaded', () => {
  carregarEntradas();
});

function validarValorNegativo(input) {
  if (input.value < 0) {
      input.value = 0;
  }
}

document.getElementById('valorInput').addEventListener('input', function() {
  let inputValue = this.value;

  let formattedValue = parseFloat(inputValue).toFixed(2);

  this.value = formattedValue;
});

function mostrarMenuEntrada() {
  const entryMenu = document.getElementById('entryMenu');
  entryMenu.classList.toggle('hidden');
}

function alternarVisibilidadeElemento(valor, elemento) {
  if (valor === 'Outro') {
    elemento.classList.remove('hidden');
  } else {
    elemento.classList.add('hidden');
  }
}

function mostrarOutroRenda() {
  const tipoRenda = document.getElementById('tipoRenda');
  const outroRenda = document.getElementById('outroRenda');
  alternarVisibilidadeElemento(tipoRenda.value, outroRenda);
}

function mostrarOutroPagamento() {
  const tipoPagamento = document.getElementById('tipoPagamento');
  const outroPagamento = document.getElementById('outroPagamento');
  alternarVisibilidadeElemento(tipoPagamento.value, outroPagamento);
}

function criarIDUnico() {
  return 'entrada_' + Date.now(); // Exemplo: entrada_1637375104447
}

function atualizarSaldo(valor) {
  saldo += parseFloat(valor);
  mostrarSaldo();
}

function carregarEntradas() {
  fetch('buscar_entradas.php')
    .then(response => response.json()) // Processando a resposta como JSON
    .then(data => {
      const entradasSalvas = document.getElementById('entradasSalvas');
      entradasSalvas.innerHTML = ''; // Limpando o conteúdo anterior

      data.forEach(entrada => {
        const novaEntrada = document.createElement('div');
        novaEntrada.classList.add('saved-entry');
        novaEntrada.innerHTML = `
          <div class="data-criacao">${entrada.data_criacao}</div>
          <p>Tipo de Renda: ${entrada.tipo_renda}</p>
          <p>Valor: R$${entrada.valor}</p>
          <p>Tipo de Pagamento: ${entrada.tipo_pagamento}</p>
          <button class="editar" onclick="editarEntrada(${entrada.entradaId})">Editar</button>
          <button class="excluir" onclick="excluirEntrada(${entrada.entradaId})">Excluir</button>
        `;
        entradasSalvas.appendChild(novaEntrada);
      });
    })
    .catch(error => console.error('Erro ao buscar entradas:', error));
}

function salvarEntrada() {
  const dataAtual = new Date();
  const dataFormatada = `${dataAtual.toLocaleDateString()} ${dataAtual.toLocaleTimeString()}`;

  const tipoRenda = document.getElementById('tipoRenda').value;
  const valor = document.getElementById('valorInput').value;
  const tipoPagamento = document.getElementById('tipoPagamento').value;

  const entradasSalvas = document.getElementById('entradasSalvas');

  const novaEntrada = document.createElement('div');
  const entradaId = criarIDUnico();
  novaEntrada.id = entradaId;

  novaEntrada.classList.add('saved-entry');
  novaEntrada.innerHTML = `
  <div class="data-criacao">${dataFormatada}</div>
      <p>Tipo de Renda: ${tipoRenda}</p>
      <p>Valor: R$${valor}</p>
      <p>Tipo de Pagamento: ${tipoPagamento}</p>
  `;

  entradasSalvas.appendChild(novaEntrada);

  novaEntrada.classList.add('entrada');

  const btnEditar = document.createElement('button');
  btnEditar.textContent = 'Editar';
  btnEditar.classList.add('editar');
  btnEditar.onclick = function() {
      editarEntrada(entradaId);
  };

  const btnExcluir = document.createElement('button');
  btnExcluir.textContent = 'Excluir';
  btnExcluir.classList.add('excluir');
  btnExcluir.onclick = function() {
      excluirEntrada(entradaId);
  };

  novaEntrada.appendChild(btnEditar);
  novaEntrada.appendChild(btnExcluir);

  const valorNumerico = parseFloat(valor);

  saldo += valorNumerico;

  atualizarSaldo(valor);
  enviarValorParaHome(valorNumerico);

  const formData = new FormData();
  formData.append('tipoRenda', tipoRenda);
  formData.append('valor', valor);
  formData.append('tipoPagamento', tipoPagamento);

  fetch('salvar_entrada.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    carregarEntradas();
  })
  .catch(error => console.error('Erro:', error));
  
  fetch('salvar_entrada.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      tipoRenda: tipoRenda,
      valor: valor,
      tipoPagamento: tipoPagamento
    })
  })
  .then(response => response.text())
  .then(data => {
    console.log(data); // Exibindo a resposta do servidor
    carregarEntradas(); // Carregando as entradas novamente após salvar
  })
  .catch(error => console.error('Erro:', error));
}

function enviarValorParaHome(valor) {
  localStorage.setItem('valorDaEntrada', valor);
}

function cancelarEntrada() {
  document.getElementById('valorInput').value = '';
  entryMenu.classList.toggle('hidden');
}

function atualizarEntradaNoServidor(entradaId, novoTipoRenda, novoValor, novoTipoPagamento) {
  fetch('atualizar_entrada.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({
          entradaId: entradaId,
          tipoRenda: novoTipoRenda,
          valor: novoValor,
          tipoPagamento: novoTipoPagamento
      })
  })
  .then(response => response.text())
  .then(data => {
      console.log(data);
      carregarEntradas();
  })
  .catch(error => console.error('Erro:', error));
}

function editarEntrada(entradaId) {

  const tipoRendaEdit = document.getElementById(`tipoRenda_${entradaId}`).textContent;
  const valorEdit = document.getElementById(`valorInput_${entradaId}`).textContent;
  const tipoPagamentoEdit = document.getElementById(`tipoPagamento_${entradaId}`).textContent;

  const novaEntrada = document.getElementById(entradaId);
  const dataCriacao = novaEntrada.querySelector('.data-criacao').textContent;

  const formEdicao = document.querySelector('.form-edicao');
  formEdicao.querySelector('.entrada-id').value = entradaId;
  formEdicao.querySelector('.tipo-renda-edit').value = tipoRendaEdit;
  formEdicao.querySelector('.valor-edit').value = valorEdit;
  formEdicao.querySelector('.tipo-pagamento-edit').value = tipoPagamentoEdit;
  formEdicao.querySelector('.data-criacao-edit').textContent = dataCriacao;

  novaEntrada.style.display = 'none';
  formEdicao.style.display = 'block';

  fetch('atualizar_entrada.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    entradaId: entradaId,
    tipoRenda: tipoRendaEdit,
    valorInput: valorEdit,
    tipoPagamento: tipoPagamentoEdit
    })
  })
  .then(response => response.text())
  .then(data => {
    console.log(data); 
    carregarEntradas();
  })
  .catch(error => console.error('Erro:', error));
}

function confirmarEdicao() {
  const entradaId = document.querySelector('.entrada-id').value;
  const novoTipoRenda = document.querySelector('.tipo-renda-edit').value;
  const novoValor = document.querySelector('.valor-edit').value;
  const novoTipoPagamento = document.querySelector('.tipo-pagamento-edit').value;

  atualizarEntradaNoServidor(entradaId, novoTipoRenda, novoValor, novoTipoPagamento);

  const entradaEditada = document.getElementById(entradaId);
  if (entradaEditada) {
      entradaEditada.querySelector('.tipo-renda-edit').textContent = `Tipo de Renda: ${novoTipoRenda}`;
      entradaEditada.querySelector('.valor-edit').textContent = `Valor: ${novoValor}`;
      entradaEditada.querySelector('.tipo-pagamento-edit').textContent = `Tipo de Pagamento: ${novoTipoPagamento}`;
  }

  const formEdicao = document.querySelector('.form-edicao');
  formEdicao.style.display = 'none';
}

function salvarEdicao(entradaId) {
  const entradaEditada = document.getElementById(entradaId);
  if (entradaEditada) {
      const novoTipoRenda = entradaEditada.querySelector('.tipo-renda-edit').value;
      const novoValor = entradaEditada.querySelector('.valor-edit').value;
      const novoTipoPagamento = entradaEditada.querySelector('.tipo-pagamento-edit').value;


      enviarDadosAtualizadosAoServidor(entradaId, novoTipoRenda, novoValor, novoTipoPagamento);
  }
}

function enviarDadosAtualizadosAoServidor(entradaId, novoTipoRenda, novoValor, novoTipoPagamento) {
  // Aqui você deve enviar uma requisição AJAX para o servidor para atualizar os dados no banco de dados
  fetch('atualizar_entrada.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          entradaId: entradaId,
          tipoRenda: novoTipoRenda,
          valor: novoValor,
          tipoPagamento: novoTipoPagamento
      })
  })
  .then(response => response.text())
  .then(data => {
      console.log(data);
      carregarEntradas();
      // Por exemplo, esconder a interface de edição e atualizar os dados na entrada exibida
  })
  .catch(error => console.error('Erro:', error));
}

function excluirEntrada(entradaId) {
  fetch('excluir_entrada.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      entradaId: entradaId
    })
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    carregarEntradas(); // Atualize a lista após a exclusão
  })
  .catch(error => console.error('Erro:', error));
}

function preencherFormularioEdicao(entrada) {
  const entradaId = entrada.querySelector('.entrada-id').value;
  const tipoRenda = entrada.querySelector('.tipoRenda').textContent;
  const valor = entrada.querySelector('.valorInput').numberContent;
  const tipoPagamento = entrada.querySelector('.tipoPagamento').textContent;

  const formEdicao = document.querySelector('.form-edicao');
  formEdicao.querySelector('.entrada-id').value = entradaId;
  formEdicao.querySelector('.tipo-renda-edit').value = tipoRenda;
  formEdicao.querySelector('.valor-edit').value = valor;
  formEdicao.querySelector('.tipo-pagamento-edit').value = tipoPagamento;

  entrada.style.display = 'none';
  formEdicao.style.display = 'block';
}

function cancelarEdicao() {
  const formEdicao = document.querySelector('.form-edicao');
  formEdicao.style.display = 'none';

  const entradaId = document.querySelector('.entrada-id').value;
  const entradaOriginal = document.getElementById(entradaId);
  if (entradaOriginal) {
    entradaOriginal.style.display = 'block';
  }
}