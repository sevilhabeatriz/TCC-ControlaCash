<?php
include 'C:/xampp/htdocs/conexão.php';

$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

// Verifique se o e-mail já está cadastrado
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "E-mail já cadastrado!";
} else {
    // Insira o novo usuário na tabela usuarios
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nome, $email, $senha);

    if ($stmt->execute()) {
        echo "Cadastro realizado com sucesso!";
    } else {
        echo "Erro no cadastro: " . $conn->error;
    }
}

$stmt->close();
$conn->close();
?>