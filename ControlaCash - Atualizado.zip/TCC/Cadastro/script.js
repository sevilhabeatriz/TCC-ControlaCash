function cadastrarUsuario() {
    // Obtenha os valores inseridos pelo usuário
    var nome = document.getElementById("cadastroNomeInput").value;
    var email = document.getElementById("cadastroEmailInput").value;
    var senha = document.getElementById("cadastroSenhaInput").value;

    // Verifique se todos os campos foram preenchidos
    if (nome && email && senha) {
      var xhr = new XMLHttpRequest();
      xhr.open("POST", "cadastro.php", true);
      xhr.setRequestHeader("Content-Type", 'application/x-www-form-urlencoded');

      // Enviar os dados para o servidor
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
          // Redirecione para a tela de login após o cadastro ser concluído
          window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Login/login.html";
        }
      };

      // Formate os dados como parâmetros de consulta
      var params = "nome=" + nome + "&email=" + email + "&senha=" + senha;

      // Envie a solicitação
      xhr.send(params);
    } else {
      // Mostre uma mensagem de erro se algum campo estiver vazio
      alert("Por favor, preencha todos os campos");
    }
  }
  
// Função para verificar o formato do e-mail
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
  // Função para salvar dados no armazenamento local
function saveUserCredentials(email, senha) {
  localStorage.setItem("userEmail", email);
  localStorage.setItem("userPassword", senha);
}

function confirmar() {
  const nameInput = document.getElementById("nameInput").value;
  const emailInput = document.getElementById("emailInput").value;
  const passwordInput = document.getElementById("passwordInput").value;
  const errorMessage = document.getElementById("errorMessage");

  // Verificar se o e-mail é válido
  if (!isValidEmail(emailInput)) {
      errorMessage.innerText = "E-mail inválido ou incorreto!";
  } else {
      if (!nameInput || !emailInput || !passwordInput) {
          errorMessage.innerText = "Preencha todos os campos!";
      } else {
          // Limpar a mensagem de erro caso não haja problemas
          errorMessage.innerText = "";
          
          // Salvar dados no armazenamento local
          saveUserCredentials(emailInput, passwordInput);

          // Redirecionar para a tela de login
          window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Login/login.html";
      }
  }
}

function cancelar() {
  document.getElementById("nameInput").value = "";
  document.getElementById("emailInput").value = "";
  document.getElementById("passwordInput").value = "";
  window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Login/login.html";
}