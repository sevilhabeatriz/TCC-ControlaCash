DROP TABLE usuarios;
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(50),
    email VARCHAR(50) UNIQUE,
    senha VARCHAR(30),
    novaSenha VARCHAR(30)
);

DROP TABLE saldo;
CREATE TABLE saldo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    saldo DECIMAL(7, 2) NOT NULL DEFAULT '0.00'
);

DROP TABLE entradas;
CREATE TABLE entradas (
    entradaId INT AUTO_INCREMENT PRIMARY KEY,
    tipo_renda VARCHAR(30),
    valor DECIMAL(7, 2),
    tipo_pagamento VARCHAR(30),
    data_criacao DATETIME NOT NULL  DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO entradas (tipo_renda, tipo_pagamento)
VALUES ('$tipo_renda', '$tipo_pagamento');

DROP TABLE saidas;
CREATE TABLE saidas (
    saidaId INT AUTO_INCREMENT PRIMARY KEY,
    tipo_gasto VARCHAR(30),
    valor DECIMAL(7, 2),
    tipo_pagamentos VARCHAR(30),
    data_criacaos DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO saidas (tipo_gasto, tipo_pagamentos)
VALUES ('$tipo_gasto', '$tipo_pagamentos');