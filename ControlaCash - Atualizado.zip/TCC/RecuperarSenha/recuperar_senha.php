<?php
include 'C:/xampp/htdocs/conexão.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = $_POST["email"];
  $novaSenha = $_POST["novaSenha"];

  $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
    $stmt = $conn->prepare("UPDATE usuarios SET senha = ? WHERE email = ?");
    $stmt->bind_param("ss", $novaSenha, $email);

    if ($stmt->execute()) {
      echo "Senha atualizada com sucesso!";
    } else {
      echo "Erro ao atualizar a senha: " . $conn->error;
    }
  } else {
    echo "E-mail não encontrado!";
  }

  $stmt->close();
  $conn->close();
}
?>