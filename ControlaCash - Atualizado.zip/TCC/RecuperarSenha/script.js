function recuperarSenha() {
  var email = document.getElementById("recoveryEmailInput").value;
  var novaSenha = document.getElementById("newPasswordInput").value;

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "recuperar_senha.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
              if (xhr.responseText === "Senha atualizada com sucesso!") {
                  alert("Senha atualizada com sucesso!");
              } else {
                  alert(xhr.responseText);
              }
          }
      }
  };

  var params = "email=" + encodeURIComponent(email) + "&novaSenha=" + encodeURIComponent(novaSenha);
  xhr.send(params);
  window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Login/login.html";
}

  function voltarParaLogin() {
    // Redirecione para a tela de login
    window.location.href = "file:///C:/Users/jvja2/OneDrive/%C3%81rea%20de%20Trabalho/TCC/Login/login.html";
  }